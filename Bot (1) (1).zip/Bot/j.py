from linepy import *#line:1
from time import sleep #line:2
import time ,random ,sys ,json ,threading ,re ,requests ,datetime ,ast ,livejson #line:3
from tools import LiveJSON ,FixJSON #line:4
cl =LINE ("Email","Password")#line:6
clm =cl .profile .mid #line:8
poll =OEPoll (cl )#line:9
print (cl .authToken )#line:10
setting ={"addct1":False ,"delct1":False ,"addct2":False ,"delct2":False ,"addct3":False ,"delct3":False ,"addct4":False ,"delct4":False ,"addct5":False ,"delct5":False ,"addct6":False ,"delct6":False ,"addct7":False ,"delct7":False }#line:27
a1 =LiveJSON ('a1.json')#line:29
b1 =LiveJSON ('b1.json')#line:30
c1 =LiveJSON ('c1.json')#line:31
a2 =LiveJSON ('a2.json')#line:33
b2 =LiveJSON ('b2.json')#line:34
c2 =LiveJSON ('c2.json')#line:35
a3 =LiveJSON ('a3.json')#line:37
b3 =LiveJSON ('b3.json')#line:38
c3 =LiveJSON ('c3.json')#line:39
a4 =LiveJSON ('a4.json')#line:41
b4 =LiveJSON ('b4.json')#line:42
c4 =LiveJSON ('c4.json')#line:43
a5 =LiveJSON ('a5.json')#line:45
b5 =LiveJSON ('b5.json')#line:46
c5 =LiveJSON ('c5.json')#line:47
a6 =LiveJSON ('a6.json')#line:49
b6 =LiveJSON ('b6.json')#line:50
c6 =LiveJSON ('c6.json')#line:51
a7 =LiveJSON ('a7.json')#line:53
b7 =LiveJSON ('b7.json')#line:54
c7 =LiveJSON ('c7.json')#line:55
b8 =LiveJSON ('b8.json')#line:57
try :#line:59
    A =cl .talk .getE2EEPublicKeys ()#line:60
    time .sleep (0.5 )#line:61
    cl .talk .removeE2EEPublicKey (A [0 ])#line:62
    time .sleep (0.5 )#line:63
except :#line:64
    pass #line:65
help ="""คำสั่งบอท
help = ดูคำสั่ง
a - g = ตั้งค่าติดตามข้อความ
1 - 8 = ปักหมุดกลุ่ม
dela - delg = ลบการติดตามข้อความ
del1 - del8 = ลบปักหมุดกลุ่ม
s (ข้อความ) ส่งข้อความไปปักหมุด 8"""#line:73
def lineBot (O0OO00000O0OOO0OO ):#line:75
    global a1 #line:76
    global b1 #line:77
    global c1 #line:78
    global a2 #line:79
    global b2 #line:80
    global c2 #line:81
    global a3 #line:82
    global b3 #line:83
    global c3 #line:84
    global a4 #line:85
    global b4 #line:86
    global c4 #line:87
    global a5 #line:88
    global b5 #line:89
    global c5 #line:90
    global a6 #line:91
    global b6 #line:92
    global c6 #line:93
    global a7 #line:94
    global b7 #line:95
    global c7 #line:96
    global b8 #line:97
    try :#line:98
        if O0OO00000O0OOO0OO .type ==26 :#line:99
            O0O0OO0O0OO0O00O0 =O0OO00000O0OOO0OO .message #line:100
            OO0OO00OOOO00000O =O0O0OO0O0OO0O00O0 .text #line:101
            if O0O0OO0O0OO0O00O0 .contentType ==0 :#line:103
                O0O0000OOO0O000O0 =[OOOO000OO000O00OO for OOOO000OO000O00OO in a1 ]#line:104
                OOOOOOOOOO000O000 =[OO000O000O0OOO00O for OO000O000O0OOO00O in c1 ]#line:105
                if O0O0OO0O0OO0O00O0 ._from in O0O0000OOO0O000O0 and O0O0OO0O0OO0O00O0 .to in OOOOOOOOOO000O000 :#line:106
                    for O0O00OO0O0O0000OO in b1 :#line:107
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:108
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:109
                OOO000O00O0000OO0 =[O0OO0OO0000O0O000 for O0OO0OO0000O0O000 in a2 ]#line:111
                OOO00000OO0O00O0O =[OOO0OOOO0O00O0000 for OOO0OOOO0O00O0000 in c2 ]#line:112
                if O0O0OO0O0OO0O00O0 ._from in OOO000O00O0000OO0 and O0O0OO0O0OO0O00O0 .to in OOO00000OO0O00O0O :#line:113
                    for O0O00OO0O0O0000OO in b2 :#line:114
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:115
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:116
                O0OO0OOO0O000OO0O =[OOOOOO00OO00OO00O for OOOOOO00OO00OO00O in a3 ]#line:118
                OOOOOO0O0O0OO0OOO =[OO0O000O00OOO00OO for OO0O000O00OOO00OO in c3 ]#line:119
                if O0O0OO0O0OO0O00O0 ._from in O0OO0OOO0O000OO0O and O0O0OO0O0OO0O00O0 .to in OOOOOO0O0O0OO0OOO :#line:120
                    for O0O00OO0O0O0000OO in b3 :#line:121
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:122
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:123
                OO00000O0OO0OO0O0 =[O0OO00O0OOOOO0O0O for O0OO00O0OOOOO0O0O in a4 ]#line:125
                OO0OO00OOOO0O00O0 =[O0OOO0O0O0OOO0O00 for O0OOO0O0O0OOO0O00 in c4 ]#line:126
                if O0O0OO0O0OO0O00O0 ._from in OO00000O0OO0OO0O0 and O0O0OO0O0OO0O00O0 .to in OO0OO00OOOO0O00O0 :#line:127
                    for O0O00OO0O0O0000OO in b4 :#line:128
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:129
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:130
                OOOO0OO00OO0OOO0O =[OO0OOO0O0OOOO0OO0 for OO0OOO0O0OOOO0OO0 in a5 ]#line:132
                OOOOOOO00O0OOOO0O =[OOOOOO0OOOOOOOOOO for OOOOOO0OOOOOOOOOO in c5 ]#line:133
                if O0O0OO0O0OO0O00O0 ._from in OOOO0OO00OO0OOO0O and O0O0OO0O0OO0O00O0 .to in OOOOOOO00O0OOOO0O :#line:134
                    for O0O00OO0O0O0000OO in b5 :#line:135
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:136
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:137
                OO00O0OO0OO0O00OO =[O00OOO00OO0OO0OOO for O00OOO00OO0OO0OOO in a6 ]#line:139
                OO00O0OOO00O0000O =[O000OOO00OOO0OO0O for O000OOO00OOO0OO0O in c6 ]#line:140
                if O0O0OO0O0OO0O00O0 ._from in OO00O0OO0OO0O00OO and O0O0OO0O0OO0O00O0 .to in OO00O0OOO00O0000O :#line:141
                    for O0O00OO0O0O0000OO in b6 :#line:142
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:143
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:144
                OOOO00O0000OO0OOO =[O0O0OOO00OO0O00OO for O0O0OOO00OO0O00OO in a7 ]#line:146
                O0O0OO0O00OO0OO0O =[O00OO0OOOOO0OOOO0 for O00OO0OOOOO0OOOO0 in c7 ]#line:147
                if O0O0OO0O0OO0O00O0 ._from in OOOO00O0000OO0OOO and O0O0OO0O0OO0O00O0 .to in O0O0OO0O00OO0OO0O :#line:148
                    for O0O00OO0O0O0000OO in b7 :#line:149
                        cl .sendMessage (O0O00OO0O0O0000OO ,O0O0OO0O0OO0O00O0 .text )#line:150
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:151
        if O0OO00000O0OOO0OO .type ==25 :#line:153
            O0O0OO0O0OO0O00O0 =O0OO00000O0OOO0OO .message #line:154
            OO0OO00OOOO00000O =O0O0OO0O0OO0O00O0 .text #line:155
            if O0O0OO0O0OO0O00O0 .contentType ==13 :#line:156
                if setting ["addct1"]==True :#line:157
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 1")#line:158
                    setting ["addct1"]=False #line:159
                    FixJSON (a1 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:160
                    FixJSON (c1 ,{O0O0OO0O0OO0O00O0 .to :True })#line:161
                if setting ["delct1"]==True :#line:163
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 1")#line:164
                    setting ["delct1"]=False #line:165
                    del a1 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:166
                    del c1 [O0O0OO0O0OO0O00O0 .to ]#line:167
                if setting ["addct2"]==True :#line:169
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 2")#line:170
                    setting ["addct2"]=False #line:171
                    FixJSON (a2 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:172
                    FixJSON (c2 ,{O0O0OO0O0OO0O00O0 .to :True })#line:173
                if setting ["delct2"]==True :#line:175
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 2")#line:176
                    setting ["delct2"]=False #line:177
                    del a2 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:178
                    del c2 [O0O0OO0O0OO0O00O0 .to ]#line:179
                if setting ["addct3"]==True :#line:181
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 3")#line:182
                    setting ["addct3"]=False #line:183
                    FixJSON (a3 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:184
                    FixJSON (c3 ,{O0O0OO0O0OO0O00O0 .to :True })#line:185
                if setting ["delct3"]==True :#line:187
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 3")#line:188
                    setting ["delct3"]=False #line:189
                    del a3 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:190
                    del c3 [O0O0OO0O0OO0O00O0 .to ]#line:191
                if setting ["addct4"]==True :#line:193
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 4")#line:194
                    setting ["addct4"]=False #line:195
                    FixJSON (a4 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:196
                    FixJSON (c4 ,{O0O0OO0O0OO0O00O0 .to :True })#line:197
                if setting ["delct4"]==True :#line:199
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 4")#line:200
                    setting ["delct4"]=False #line:201
                    del a4 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:202
                    del c4 [O0O0OO0O0OO0O00O0 .to ]#line:203
                if setting ["addct5"]==True :#line:205
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 5")#line:206
                    setting ["addct5"]=False #line:207
                    FixJSON (a5 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:208
                    FixJSON (c5 ,{O0O0OO0O0OO0O00O0 .to :True })#line:209
                if setting ["delct5"]==True :#line:211
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 5")#line:212
                    setting ["delct5"]=False #line:213
                    del a5 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:214
                    del c5 [O0O0OO0O0OO0O00O0 .to ]#line:215
                if setting ["addct6"]==True :#line:217
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 6")#line:218
                    setting ["addct6"]=False #line:219
                    FixJSON (a6 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:220
                    FixJSON (c6 ,{O0O0OO0O0OO0O00O0 .to :True })#line:221
                if setting ["delct6"]==True :#line:223
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 6")#line:224
                    setting ["delct6"]=False #line:225
                    del a6 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:226
                    del c6 [O0O0OO0O0OO0O00O0 .to ]#line:227
                if setting ["addct7"]==True :#line:229
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"สำเร็จแล้วบัญชีที่ 7")#line:230
                    setting ["addct7"]=False #line:231
                    FixJSON (a7 ,{O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]:True })#line:232
                    FixJSON (c7 ,{O0O0OO0O0OO0O00O0 .to :True })#line:233
                if setting ["delct7"]==True :#line:235
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 7")#line:236
                    setting ["delct7"]=False #line:237
                    del a7 [O0O0OO0O0OO0O00O0 .contentMetadata ["mid"]]#line:238
                    del c7 [O0O0OO0O0OO0O00O0 .to ]#line:239
            if O0O0OO0O0OO0O00O0 .contentType ==0 :#line:241
                if OO0OO00OOOO00000O .lower ()=='help':#line:242
                   cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,str (help ))#line:243
                if OO0OO00OOOO00000O .lower ()=='a':#line:245
                    setting ["addct1"]=True #line:246
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:247
                if OO0OO00OOOO00000O .lower ()=='b':#line:249
                    setting ["addct2"]=True #line:250
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:251
                if OO0OO00OOOO00000O .lower ()=='c':#line:253
                    setting ["addct3"]=True #line:254
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:255
                if OO0OO00OOOO00000O .lower ()=='d':#line:257
                    setting ["addct4"]=True #line:258
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:259
                if OO0OO00OOOO00000O .lower ()=='e':#line:261
                    setting ["addct5"]=True #line:262
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:263
                if OO0OO00OOOO00000O .lower ()=='f':#line:265
                    setting ["addct6"]=True #line:266
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:267
                if OO0OO00OOOO00000O .lower ()=='g':#line:269
                    setting ["addct7"]=True #line:270
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:271
                if OO0OO00OOOO00000O .lower ()=='dela':#line:273
                    setting ["delct1"]=True #line:274
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:275
                if OO0OO00OOOO00000O .lower ()=='delb':#line:277
                    setting ["delct2"]=True #line:278
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:279
                if OO0OO00OOOO00000O .lower ()=='delc':#line:281
                    setting ["delct3"]=True #line:282
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:283
                if OO0OO00OOOO00000O .lower ()=='deld':#line:285
                    setting ["delct4"]=True #line:286
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:287
                if OO0OO00OOOO00000O .lower ()=='dele':#line:289
                    setting ["delct5"]=True #line:290
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:291
                if OO0OO00OOOO00000O .lower ()=='delf':#line:293
                    setting ["delct6"]=True #line:294
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:295
                if OO0OO00OOOO00000O .lower ()=='delg':#line:297
                    setting ["delct7"]=True #line:298
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"กรุณาส่ง Contact.")#line:299
                if OO0OO00OOOO00000O .lower ()=='1':#line:301
                    FixJSON (b1 ,{O0O0OO0O0OO0O00O0 .to :True })#line:302
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 1")#line:303
                if OO0OO00OOOO00000O .lower ()=='2':#line:305
                    FixJSON (b2 ,{O0O0OO0O0OO0O00O0 .to :True })#line:306
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 2")#line:307
                if OO0OO00OOOO00000O .lower ()=='3':#line:309
                    FixJSON (b3 ,{O0O0OO0O0OO0O00O0 .to :True })#line:310
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 3")#line:311
                if OO0OO00OOOO00000O .lower ()=='4':#line:313
                    FixJSON (b4 ,{O0O0OO0O0OO0O00O0 .to :True })#line:314
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 4")#line:315
                if OO0OO00OOOO00000O .lower ()=='5':#line:317
                    FixJSON (b5 ,{O0O0OO0O0OO0O00O0 .to :True })#line:318
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 5")#line:319
                if OO0OO00OOOO00000O .lower ()=='6':#line:321
                    FixJSON (b6 ,{O0O0OO0O0OO0O00O0 .to :True })#line:322
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 6")#line:323
                if OO0OO00OOOO00000O .lower ()=='7':#line:325
                    FixJSON (b7 ,{O0O0OO0O0OO0O00O0 .to :True })#line:326
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 7")#line:327
                if OO0OO00OOOO00000O .lower ()=='8':#line:329
                    FixJSON (b8 ,{O0O0OO0O0OO0O00O0 .to :True })#line:330
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"เพิ่มกลุ่มสำเร็จ 8")#line:331
                if OO0OO00OOOO00000O .lower ()=='del1':#line:333
                    try :#line:334
                        del b1 [O0O0OO0O0OO0O00O0 .to ]#line:335
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:336
                    except :#line:337
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:338
                if OO0OO00OOOO00000O .lower ()=='del2':#line:340
                    try :#line:341
                        del b2 [O0O0OO0O0OO0O00O0 .to ]#line:342
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:343
                    except :#line:344
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:345
                if OO0OO00OOOO00000O .lower ()=='del3':#line:347
                    try :#line:348
                        del b3 [O0O0OO0O0OO0O00O0 .to ]#line:349
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:350
                    except :#line:351
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:352
                if OO0OO00OOOO00000O .lower ()=='del4':#line:354
                    try :#line:355
                        del b4 [O0O0OO0O0OO0O00O0 .to ]#line:356
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:357
                    except :#line:358
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:359
                if OO0OO00OOOO00000O .lower ()=='del5':#line:361
                    try :#line:362
                        del b5 [O0O0OO0O0OO0O00O0 .to ]#line:363
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:364
                    except :#line:365
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:366
                if OO0OO00OOOO00000O .lower ()=='del6':#line:368
                    try :#line:369
                        del b6 [O0O0OO0O0OO0O00O0 .to ]#line:370
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:371
                    except :#line:372
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:373
                if OO0OO00OOOO00000O .lower ()=='del7':#line:375
                    try :#line:376
                        del b7 [O0O0OO0O0OO0O00O0 .to ]#line:377
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:378
                    except :#line:379
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:380
                if OO0OO00OOOO00000O .lower ()=='del8':#line:382
                    try :#line:383
                        del b8 [O0O0OO0O0OO0O00O0 .to ]#line:384
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:385
                    except :#line:386
                        cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,'ลบสำเร็จ')#line:387
                if O0O0OO0O0OO0O00O0 .text .startswith ("s "):#line:389
                    OO0OO00OOOO00000O =" ".join (O0O0OO0O0OO0O00O0 .text .split (" ")[1 :])#line:390
                    for OO00OO0O0O00O0OOO in b8 :#line:391
                        cl .sendMessage (OO00OO0O0O00O0OOO ,OO0OO00OOOO00000O )#line:392
                        time .sleep (1 )#line:393
                    cl .sendMessage (O0O0OO0O0OO0O00O0 .to ,"ส่งสำเร็จแล้ว")#line:394
    except Exception as OO0O00O0O0OO0O00O :#line:396
        print (OO0O00O0O0OO0O00O .args )#line:397
while True :#line:399
    try :#line:400
        ops =poll .singleTrace (count =50 )#line:401
        if ops is not None :#line:402
            for op in ops :#line:403
                lineBot (op )#line:404
                poll .setRevision (op .revision )#line:405
    except KeyboardInterrupt :#line:406
        sys .exit ()#line:407
    except Exception as e :#line:408
        print (e .args )#line:409
