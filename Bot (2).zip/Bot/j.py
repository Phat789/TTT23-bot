from linepy import *#line:1
from time import sleep #line:2
import time ,random ,sys ,json ,threading ,re ,requests ,datetime ,ast ,livejson #line:3
from tools import LiveJSON ,FixJSON #line:4


cl = LINE ("อีเมล" ,"รหัส")
  
        
clm =cl .profile .mid #line:8
poll =OEPoll (cl )#line:9
print (cl .authToken )#line:10
setting ={"addct1":False ,"delct1":False ,"addct2":False ,"delct2":False ,"addct3":False ,"delct3":False ,"addct4":False ,"delct4":False ,"addct5":False ,"delct5":False ,"addct6":False ,"delct6":False ,"addct7":False ,"delct7":False }#line:27
a1 =LiveJSON ('a1.json')#line:29
b1 =LiveJSON ('b1.json')#line:30
c1 =LiveJSON ('c1.json')#line:31
a2 =LiveJSON ('a2.json')#line:33
b2 =LiveJSON ('b2.json')#line:34
c2 =LiveJSON ('c2.json')#line:35
a3 =LiveJSON ('a3.json')#line:37
b3 =LiveJSON ('b3.json')#line:38
c3 =LiveJSON ('c3.json')#line:39
a4 =LiveJSON ('a4.json')#line:41
b4 =LiveJSON ('b4.json')#line:42
c4 =LiveJSON ('c4.json')#line:43
a5 =LiveJSON ('a5.json')#line:45
b5 =LiveJSON ('b5.json')#line:46
c5 =LiveJSON ('c5.json')#line:47
a6 =LiveJSON ('a6.json')#line:49
b6 =LiveJSON ('b6.json')#line:50
c6 =LiveJSON ('c6.json')#line:51
a7 =LiveJSON ('a7.json')#line:53
b7 =LiveJSON ('b7.json')#line:54
c7 =LiveJSON ('c7.json')#line:55
b8 =LiveJSON ('b8.json')#line:57
b9 =LiveJSON ('b9.json')#line:58
b10 =LiveJSON ('b10.json')#line:59
b11 =LiveJSON ('b11.json')#line:60
b12 =LiveJSON ('b12.json')#line:61
b13 =LiveJSON ('b13.json')#line:62
b14 =LiveJSON ('b14.json')#line:63
try :#line:65
    A =cl .talk .getE2EEPublicKeys ()#line:66
    time .sleep (0.5 )#line:67
    cl .talk .removeE2EEPublicKey (A [0 ])#line:68
    time .sleep (0.5 )#line:69
except :#line:70
    pass #line:71
help ="""คำสั่งบอท
help = ดูคำสั่ง
เพิ่มตาม1 - เพิ่มตาม7 = ตั้งค่าติดตามข้อความ
ลบตาม1 - ลบตาม7 = ลบการติดตาม
ปัก1 - ปัก7 = ปักหมุดกลุ่ม
ลบปัก1 - ลบปัก7 = ลบปักหมุดกลุ่ม
หมุด1 - หมุด7 = ปักหมุดประกาศ
ลบหมุด1 - ลบหมุด7 = ลบปักหมุดประกาศ
บอกหมุด1 - บอกหมุด7 (ข้อความ) ส่งข้อความไปบอกหมุด"""#line:81
def lineBot (O00OOOOOOOO00OO00 ):#line:83
    global a1 #line:84
    global b1 #line:85
    global c1 #line:86
    global a2 #line:87
    global b2 #line:88
    global c2 #line:89
    global a3 #line:90
    global b3 #line:91
    global c3 #line:92
    global a4 #line:93
    global b4 #line:94
    global c4 #line:95
    global a5 #line:96
    global b5 #line:97
    global c5 #line:98
    global a6 #line:99
    global b6 #line:100
    global c6 #line:101
    global a7 #line:102
    global b7 #line:103
    global c7 #line:104
    global b8 #line:105
    global b9 #line:106
    global b10 #line:107
    global b11 #line:108
    global b12 #line:109
    global b13 #line:110
    global b14 #line:111
    try :#line:112
        if O00OOOOOOOO00OO00 .type ==26 :#line:113
            O0O0O00000OOO00O0 =O00OOOOOOOO00OO00 .message #line:114
            OO00O00000OOOO000 =O0O0O00000OOO00O0 .text #line:115
            if O0O0O00000OOO00O0 .contentType ==0 :#line:117
                OO0OO000O00O0OOO0 =[OO0OO0O00000OO0O0 for OO0OO0O00000OO0O0 in a1 ]#line:118
                OOOOOO0O00000O0O0 =[O0OO0O00000OOO000 for O0OO0O00000OOO000 in c1 ]#line:119
                if O0O0O00000OOO00O0 ._from in OO0OO000O00O0OOO0 and O0O0O00000OOO00O0 .to in OOOOOO0O00000O0O0 :#line:120
                    for O000000O0O000OO0O in b1 :#line:121
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:122
                O000O0O00OO0OO0OO =[OO0O0OOOO0OO00O0O for OO0O0OOOO0OO00O0O in a2 ]#line:124
                OO00OOO00O0O00OO0 =[OOO0O0OO0OO0O00OO for OOO0O0OO0OO0O00OO in c2 ]#line:125
                if O0O0O00000OOO00O0 ._from in O000O0O00OO0OO0OO and O0O0O00000OOO00O0 .to in OO00OOO00O0O00OO0 :#line:126
                    for O000000O0O000OO0O in b2 :#line:127
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:128
                O0O000O0OO0000000 =[O00OOO0OO0O0O00OO for O00OOO0OO0O0O00OO in a3 ]#line:130
                OOO0OO0O0OO0OOO0O =[OO0000OOOOO000O0O for OO0000OOOOO000O0O in c3 ]#line:131
                if O0O0O00000OOO00O0 ._from in O0O000O0OO0000000 and O0O0O00000OOO00O0 .to in OOO0OO0O0OO0OOO0O :#line:132
                    for O000000O0O000OO0O in b3 :#line:133
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:134
                OOOOO00000O0OOOOO =[OOOO0O000O000O000 for OOOO0O000O000O000 in a4 ]#line:136
                OO00OOOO0OO000O0O =[OOO0OOOO0O00O000O for OOO0OOOO0O00O000O in c4 ]#line:137
                if O0O0O00000OOO00O0 ._from in OOOOO00000O0OOOOO and O0O0O00000OOO00O0 .to in OO00OOOO0OO000O0O :#line:138
                    for O000000O0O000OO0O in b4 :#line:139
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:140
                OOOOOOOO00OOO0O0O =[O00OO00OOOOO0000O for O00OO00OOOOO0000O in a5 ]#line:142
                O0OO0OOO000O0O0O0 =[O000OOO0O0OO0O0O0 for O000OOO0O0OO0O0O0 in c5 ]#line:143
                if O0O0O00000OOO00O0 ._from in OOOOOOOO00OOO0O0O and O0O0O00000OOO00O0 .to in O0OO0OOO000O0O0O0 :#line:144
                    for O000000O0O000OO0O in b5 :#line:145
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:146
                O0O0OOOO0OO00OOO0 =[OOOOO0O0000OOO0OO for OOOOO0O0000OOO0OO in a6 ]#line:148
                OO0OO00O000000000 =[O0000OO0OO00O0O00 for O0000OO0OO00O0O00 in c6 ]#line:149
                if O0O0O00000OOO00O0 ._from in O0O0OOOO0OO00OOO0 and O0O0O00000OOO00O0 .to in OO0OO00O000000000 :#line:150
                    for O000000O0O000OO0O in b6 :#line:151
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:152
                O00O00O00OO00O000 =[O00000000OO00O00O for O00000000OO00O00O in a7 ]#line:154
                OOOO0O0OO00O000OO =[O0OOO00OO00O0OO0O for O0OOO00OO00O0OO0O in c7 ]#line:155
                if O0O0O00000OOO00O0 ._from in O00O00O00OO00O000 and O0O0O00000OOO00O0 .to in OOOO0O0OO00O000OO :#line:156
                    for O000000O0O000OO0O in b7 :#line:157
                        cl .sendMessage (O000000O0O000OO0O ,O0O0O00000OOO00O0 .text )#line:158
        if O00OOOOOOOO00OO00 .type ==25 :#line:160
            O0O0O00000OOO00O0 =O00OOOOOOOO00OO00 .message #line:161
            OO00O00000OOOO000 =O0O0O00000OOO00O0 .text #line:162
            if O0O0O00000OOO00O0 .contentType ==13 :#line:163
                if setting ["addct1"]==True :#line:164
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 1")#line:165
                    setting ["addct1"]=False #line:166
                    FixJSON (a1 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:167
                    FixJSON (c1 ,{O0O0O00000OOO00O0 .to :True })#line:168
                if setting ["delct1"]==True :#line:170
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบตามสำเร็จแล้วบัญชีที่ 1")#line:171
                    setting ["delct1"]=False #line:172
                    del a1 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:173
                    del c1 [O0O0O00000OOO00O0 .to ]#line:174
                if setting ["addct2"]==True :#line:176
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 2")#line:177
                    setting ["addct2"]=False #line:178
                    FixJSON (a2 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:179
                    FixJSON (c2 ,{O0O0O00000OOO00O0 .to :True })#line:180
                if setting ["delct2"]==True :#line:182
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบตามสำเร็จแล้วบัญชีที่ 2")#line:183
                    setting ["delct2"]=False #line:184
                    del a2 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:185
                    del c2 [O0O0O00000OOO00O0 .to ]#line:186
                if setting ["addct3"]==True :#line:188
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 3")#line:189
                    setting ["addct3"]=False #line:190
                    FixJSON (a3 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:191
                    FixJSON (c3 ,{O0O0O00000OOO00O0 .to :True })#line:192
                if setting ["delct3"]==True :#line:194
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบตามสำเร็จแล้วบัญชีที่ 3")#line:195
                    setting ["delct3"]=False #line:196
                    del a3 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:197
                    del c3 [O0O0O00000OOO00O0 .to ]#line:198
                if setting ["addct4"]==True :#line:200
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 4")#line:201
                    setting ["addct4"]=False #line:202
                    FixJSON (a4 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:203
                    FixJSON (c4 ,{O0O0O00000OOO00O0 .to :True })#line:204
                if setting ["delct4"]==True :#line:206
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบตามสำเร็จแล้วบัญชีที่ 4")#line:207
                    setting ["delct4"]=False #line:208
                    del a4 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:209
                    del c4 [O0O0O00000OOO00O0 .to ]#line:210
                if setting ["addct5"]==True :#line:212
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 5")#line:213
                    setting ["addct5"]=False #line:214
                    FixJSON (a5 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:215
                    FixJSON (c5 ,{O0O0O00000OOO00O0 .to :True })#line:216
                if setting ["delct5"]==True :#line:218
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบตามสำเร็จแล้วบัญชีที่ 5")#line:219
                    setting ["delct5"]=False #line:220
                    del a5 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:221
                    del c5 [O0O0O00000OOO00O0 .to ]#line:222
                if setting ["addct6"]==True :#line:224
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 6")#line:225
                    setting ["addct6"]=False #line:226
                    FixJSON (a6 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:227
                    FixJSON (c6 ,{O0O0O00000OOO00O0 .to :True })#line:228
                if setting ["delct6"]==True :#line:230
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบตามสำเร็จแล้วบัญชีที่ 6")#line:231
                    setting ["delct6"]=False #line:232
                    del a6 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:233
                    del c6 [O0O0O00000OOO00O0 .to ]#line:234
                if setting ["addct7"]==True :#line:236
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มตามสำเร็จแล้วบัญชีที่ 7")#line:237
                    setting ["addct7"]=False #line:238
                    FixJSON (a7 ,{O0O0O00000OOO00O0 .contentMetadata ["mid"]:True })#line:239
                    FixJSON (c7 ,{O0O0O00000OOO00O0 .to :True })#line:240
                if setting ["delct7"]==True :#line:242
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ลบสำเร็จแล้วบัญชีที่ 7")#line:243
                    setting ["delct7"]=False #line:244
                    del a7 [O0O0O00000OOO00O0 .contentMetadata ["mid"]]#line:245
                    del c7 [O0O0O00000OOO00O0 .to ]#line:246
            if O0O0O00000OOO00O0 .contentType ==0 :#line:248
                if OO00O00000OOOO000 .lower ()=='help':#line:249
                   cl .sendMessage (O0O0O00000OOO00O0 .to ,str (help ))#line:250
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม1':#line:252
                    setting ["addct1"]=True #line:253
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:254
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม2':#line:256
                    setting ["addct2"]=True #line:257
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:258
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม3':#line:260
                    setting ["addct3"]=True #line:261
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:262
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม4':#line:264
                    setting ["addct4"]=True #line:265
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:266
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม5':#line:268
                    setting ["addct5"]=True #line:269
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:270
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม6':#line:272
                    setting ["addct6"]=True #line:273
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:274
                if OO00O00000OOOO000 .lower ()=='เพิ่มตาม7':#line:276
                    setting ["addct7"]=True #line:277
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:278
                if OO00O00000OOOO000 .lower ()=='ลบตาม1':#line:280
                    setting ["delct1"]=True #line:281
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:282
                if OO00O00000OOOO000 .lower ()=='ลบตาม2':#line:284
                    setting ["delct2"]=True #line:285
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:286
                if OO00O00000OOOO000 .lower ()=='ลบตาม3':#line:288
                    setting ["delct3"]=True #line:289
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:290
                if OO00O00000OOOO000 .lower ()=='ลบตาม4':#line:292
                    setting ["delct4"]=True #line:293
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:294
                if OO00O00000OOOO000 .lower ()=='ลบตาม5':#line:296
                    setting ["delct5"]=True #line:297
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:298
                if OO00O00000OOOO000 .lower ()=='ลบตาม6':#line:300
                    setting ["delct6"]=True #line:301
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:302
                if OO00O00000OOOO000 .lower ()=='ลบตาม7':#line:304
                    setting ["delct7"]=True #line:305
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"กรุณาส่ง Contact.")#line:306
                if OO00O00000OOOO000 .lower ()=='ปัก1':#line:308
                    FixJSON (b1 ,{O0O0O00000OOO00O0 .to :True })#line:309
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 1")#line:310
                if OO00O00000OOOO000 .lower ()=='ปัก2':#line:312
                    FixJSON (b2 ,{O0O0O00000OOO00O0 .to :True })#line:313
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 2")#line:314
                if OO00O00000OOOO000 .lower ()=='ปัก3':#line:316
                    FixJSON (b3 ,{O0O0O00000OOO00O0 .to :True })#line:317
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 3")#line:318
                if OO00O00000OOOO000 .lower ()=='ปัก4':#line:320
                    FixJSON (b4 ,{O0O0O00000OOO00O0 .to :True })#line:321
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 4")#line:322
                if OO00O00000OOOO000 .lower ()=='ปัก5':#line:324
                    FixJSON (b5 ,{O0O0O00000OOO00O0 .to :True })#line:325
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 5")#line:326
                if OO00O00000OOOO000 .lower ()=='ปัก6':#line:328
                    FixJSON (b6 ,{O0O0O00000OOO00O0 .to :True })#line:329
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 6")#line:330
                if OO00O00000OOOO000 .lower ()=='ปัก7':#line:332
                    FixJSON (b7 ,{O0O0O00000OOO00O0 .to :True })#line:333
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มปักสำเร็จ 7")#line:334
                if OO00O00000OOOO000 .lower ()=='หมุด1':#line:336
                    FixJSON (b8 ,{O0O0O00000OOO00O0 .to :True })#line:337
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 1")#line:338
                if OO00O00000OOOO000 .lower ()=='หมุด2':#line:340
                    FixJSON (b9 ,{O0O0O00000OOO00O0 .to :True })#line:341
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 2")#line:342
                if OO00O00000OOOO000 .lower ()=='หมุด3':#line:344
                    FixJSON (b10 ,{O0O0O00000OOO00O0 .to :True })#line:345
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 3")#line:346
                if OO00O00000OOOO000 .lower ()=='หมุด4':#line:348
                    FixJSON (b11 ,{O0O0O00000OOO00O0 .to :True })#line:349
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 4")#line:350
                if OO00O00000OOOO000 .lower ()=='หมุด5':#line:352
                    FixJSON (b12 ,{O0O0O00000OOO00O0 .to :True })#line:353
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 5")#line:354
                if OO00O00000OOOO000 .lower ()=='หมุด6':#line:356
                    FixJSON (b13 ,{O0O0O00000OOO00O0 .to :True })#line:357
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 6")#line:358
                if OO00O00000OOOO000 .lower ()=='หมุด7':#line:360
                    FixJSON (b14 ,{O0O0O00000OOO00O0 .to :True })#line:361
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"เพิ่มหมุดสำเร็จ 7")#line:362
                if OO00O00000OOOO000 .lower ()=='ลบปัก1':#line:364
                    try :#line:365
                        del b1 [O0O0O00000OOO00O0 .to ]#line:366
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:367
                    except :#line:368
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:369
                if OO00O00000OOOO000 .lower ()=='ลบปัก2':#line:371
                    try :#line:372
                        del b2 [O0O0O00000OOO00O0 .to ]#line:373
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:374
                    except :#line:375
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:376
                if OO00O00000OOOO000 .lower ()=='ลบปัก3':#line:378
                    try :#line:379
                        del b3 [O0O0O00000OOO00O0 .to ]#line:380
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:381
                    except :#line:382
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:383
                if OO00O00000OOOO000 .lower ()=='ลบปัก4':#line:385
                    try :#line:386
                        del b4 [O0O0O00000OOO00O0 .to ]#line:387
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:388
                    except :#line:389
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:390
                if OO00O00000OOOO000 .lower ()=='ลบปัก5':#line:392
                    try :#line:393
                        del b5 [O0O0O00000OOO00O0 .to ]#line:394
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:395
                    except :#line:396
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:397
                if OO00O00000OOOO000 .lower ()=='ลบปัก6':#line:399
                    try :#line:400
                        del b6 [O0O0O00000OOO00O0 .to ]#line:401
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:402
                    except :#line:403
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:404
                if OO00O00000OOOO000 .lower ()=='ลบปัก7':#line:406
                    try :#line:407
                        del b7 [O0O0O00000OOO00O0 .to ]#line:408
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:409
                    except :#line:410
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:411
                if OO00O00000OOOO000 .lower ()=='ลบหมุด1':#line:413
                    try :#line:414
                        del b8 [O0O0O00000OOO00O0 .to ]#line:415
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:416
                    except :#line:417
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:418
                if OO00O00000OOOO000 .lower ()=='ลบหมุด2':#line:420
                    try :#line:421
                        del b9 [O0O0O00000OOO00O0 .to ]#line:422
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:423
                    except :#line:424
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:425
                if OO00O00000OOOO000 .lower ()=='ลบหมุด3':#line:427
                    try :#line:428
                        del b10 [O0O0O00000OOO00O0 .to ]#line:429
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:430
                    except :#line:431
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:432
                if OO00O00000OOOO000 .lower ()=='ลบหมุด4':#line:434
                    try :#line:435
                        del b11 [O0O0O00000OOO00O0 .to ]#line:436
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:437
                    except :#line:438
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:439
                if OO00O00000OOOO000 .lower ()=='ลบหมุด5':#line:441
                    try :#line:442
                        del b12 [O0O0O00000OOO00O0 .to ]#line:443
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:444
                    except :#line:445
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:446
                if OO00O00000OOOO000 .lower ()=='ลบหมุด6':#line:448
                    try :#line:449
                        del b13 [O0O0O00000OOO00O0 .to ]#line:450
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:451
                    except :#line:452
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:453
                if OO00O00000OOOO000 .lower ()=='ลบหมุด7':#line:455
                    try :#line:456
                        del b14 [O0O0O00000OOO00O0 .to ]#line:457
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:458
                    except :#line:459
                        cl .sendMessage (O0O0O00000OOO00O0 .to ,'ลบสำเร็จ')#line:460
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด1 "):#line:462
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:463
                    for OOOOO000OO000OO00 in b8 :#line:464
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:465
                        time .sleep (1 )#line:466
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:467
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด2 "):#line:469
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:470
                    for OOOOO000OO000OO00 in b9 :#line:471
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:472
                        time .sleep (1 )#line:473
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:474
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด3 "):#line:476
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:477
                    for OOOOO000OO000OO00 in b10 :#line:478
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:479
                        time .sleep (1 )#line:480
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:481
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด4 "):#line:483
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:484
                    for OOOOO000OO000OO00 in b11 :#line:485
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:486
                        time .sleep (1 )#line:487
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:488
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด5 "):#line:490
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:491
                    for OOOOO000OO000OO00 in b12 :#line:492
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:493
                        time .sleep (1 )#line:494
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:495
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด6 "):#line:497
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:498
                    for OOOOO000OO000OO00 in b13 :#line:499
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:500
                        time .sleep (1 )#line:501
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:502
                if O0O0O00000OOO00O0 .text .startswith ("บอกหมุด7 "):#line:504
                    OO00O00000OOOO000 =" ".join (O0O0O00000OOO00O0 .text .split (" ")[1 :])#line:505
                    for OOOOO000OO000OO00 in b14 :#line:506
                        cl .sendMessage (OOOOO000OO000OO00 ,OO00O00000OOOO000 )#line:507
                        time .sleep (1 )#line:508
                    cl .sendMessage (O0O0O00000OOO00O0 .to ,"ส่งสำเร็จแล้ว")#line:509
    except Exception as O00OO0O0OOOO0OO0O :#line:511
        print (O00OO0O0OOOO0OO0O .args )#line:512
while True :#line:514
    try :#line:515
        ops =poll .singleTrace (count =50 )#line:516
        if ops is not None :#line:517
            for op in ops :#line:518
                lineBot (op )#line:519
                poll .setRevision (op .revision )#line:520
    except KeyboardInterrupt :#line:521
        sys .exit ()#line:522
    except Exception as e :#line:523
        print (e .args )#line:524
